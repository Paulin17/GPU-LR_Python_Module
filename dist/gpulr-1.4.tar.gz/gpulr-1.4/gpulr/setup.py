def main():
    print("Hello from GPU script!")

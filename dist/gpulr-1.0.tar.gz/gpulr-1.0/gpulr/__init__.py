from .fonctions import get_connection,get_infos,list_semaine,get_Semaine
from .action import parse_multiple_events
from .class_perso import Event,Student,Agenda